#include "Boton.h"

Boton::Boton(int xArr,int yArr,char* nombre,int color,int separar)
{
    this->xArr = xArr;
    this->yArr = yArr;
    this->xAba = xArr + separar;
    this->yAba = yArr + 60;
    this->color = color;
    this->nombre = nombre;
}

void Boton::dibujar()
{
    settextjustify(1, 1);
    settextstyle(3, 0, 1);
    setfillstyle(this->color,this->color);
    setcolor(this->color);
    bar3d(this->xArr, this->yArr, this->xAba, this->yAba,30,1);
    outtextxy((this->xArr+this->xAba) / 2, (this->yArr+30 + this->yAba) / 2, nombre);
}

Boton::~Boton()
{
    //dtor
}
