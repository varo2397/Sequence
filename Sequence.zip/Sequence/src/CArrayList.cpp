#include "CArrayList.h"
#include <iostream>
#include <stdexcept>
#include <math.h>
#include "Jugador.h" //No estaba
using namespace std;


template <class E>
CArrayList<E>::CArrayList()
{
    size = 0;
    pos = 0;
}

template <class E>
CArrayList<E>::CArrayList(int pMax)
{
    ///Constructor
    max = pMax;
    size = 0;
    pos = 0;
    elements = new E[pMax];
}

template <class E>
CArrayList<E>::~CArrayList()
{
    ///Destructor
    size = 0;
    pos = 0;
    delete[]elements;
}


template <class E>
void CArrayList<E>::setArraySize(int size)
{
    max = size;
    elements = new E[size];
}

template <class E>
E CArrayList<E>::getValue()
{
    ///Muestra el elemento de la lista
    if((pos < 0) || (pos > size))
    {
        throw runtime_error("Index out of bounds");
    }

    return elements[pos];
}

template <class E>
E& CArrayList<E>::returnValue()
{
    E& temp = elements[pos];
    return temp;
}

template <class E>
int CArrayList<E>::getPos()
{
    ///Retorna la posicion actual
    return pos;
}

template <class E>
int CArrayList<E>::getSize()
{
    ///Retorna el tama�o de la lista
    return size;
}

template <class E>
void CArrayList<E>::goToStart()
{
    ///Se mueve al inico de la lista
    pos = 0;
}

template <class E>
void CArrayList<E>::goToEnd()
{
    ///Se mueve al final de la lista
    pos = size-1;
}

template <class E>
void CArrayList<E>::goToPos(int pos)
{
    ///Se mueve a una posicion de la lista
    this->pos = pos; //El atributo pos = la variable pos
}

template <class E>
void CArrayList<E>::previous()
{
    ///Se mueve una posicion atras
    pos--;

    this->pos = fabs(pos%getSize());


}

template <class E>
void CArrayList<E>::next()
{
    ///Se mueve una posicion adelante
    pos++;

    this->pos = pos%getSize();


}

template <class E>
void CArrayList<E>::append(E pElement)
{
    ///Inserta un elemento al final de la lista
//    if(size == max)
//    {
//        throw runtime_error("List full");
//    }

    elements[size] = pElement;
    size++;
}

template <class E>
void CArrayList<E>::insert(int pos, E pElement)
{
    ///Inserta un elemento en la lista
    goToPos(pos);

    if(size==max)
    {
        throw runtime_error("List full");
    }

    for(int i=size; i>pos; i--)
    {
        elements[i] = elements[i-1];
    }

    elements[pos] = pElement;
    size++;
}

template <class E>
E CArrayList<E>::remove(int pos)
{
    ///Elimina un elemento de la lista
    if(size==0)
    {
        throw runtime_error("Empty list");
    }

    goToPos(pos);
    E deletedElement = elements[pos];

    for(int i=pos; i<size; i++)
    {
        elements[i] = elements[i+1];
    }

    size--;

    return deletedElement;
}



template class CArrayList<Jugador>; //No estaba
template class CArrayList<Carta>;
