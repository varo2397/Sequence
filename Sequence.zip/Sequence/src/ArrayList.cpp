#include "ArrayList.h"
#include <iostream>
#define Default_max_size 1024
#include <stdexcept>

using namespace std;
template <class E>
ArrayList<E>::ArrayList(int pMax)
{
    max = pMax;
    size = 0;
    pos = 0;
    elements = new E[pMax];
    cout<<pMax;
}

template <class E>
E ArrayList<E>::getValue()
{
    if((pos < 0) || (pos > size))
    {
    throw runtime_error("Index out of range");
    }

    return elements[pos];
}
template <class E>
int ArrayList<E>::getPos()
{
    return pos;
}
template <class E>
int ArrayList<E>::getSize()
{
    return size;
}
template <class E>
void ArrayList<E>::goToStart()
{
    pos = 0;
}
template <class E>
void ArrayList<E>::goToEnd()
{
    pos = size-1;
}
template <class E>
void ArrayList<E>::next(){
    if(pos < size){
        pos++;
    }
}
template <class E>
void ArrayList<E>::previous(){
    pos--;
}
template <class E>
void ArrayList<E>::goToPos(int pos){
    this->pos = pos;
}
template <class E>
void ArrayList<E>::append(E pElement){
   if(size == max){
        throw runtime_error ("List full");
   }
        elements[size] = pElement;
        size++;
}

template <class E>
void ArrayList<E>::insert(E pElement, int pos){
    //poner a pos a apuntar donde quiero insertar invocando a gotoPos
    if(size == max){
        throw runtime_error ("List full");
    }
    goToPos(pos);
    for(int i = size; i>pos; i--){
        elements[i] = elements[i-1];

    }
    elements[pos] = pElement;
    size++;
}
template <class E>
E ArrayList<E>::remove(int pos){
    if(size == 0){
        throw runtime_error("Empty list");
    }

    goToPos(pos);
    E deletedElement = elements[pos];
    for(int i = pos; i < size; i++){
        elements[i] = elements[i + 1];

    }
    size--;
    return(deletedElement);

}
/*
template <class E>
void ArrayList<E>::print(){
    for(int i = 0;size > i; i++){
        cout <<" " << elements[i];
    }
    cout << endl;

}
*/
template <class E>
ArrayList<E>::~ArrayList(){
    //destructor de la clase
    size = 0;
    pos = 0;
    delete []elements;
}
template class ArrayList<Carta>;
template class ArrayList<int>;
