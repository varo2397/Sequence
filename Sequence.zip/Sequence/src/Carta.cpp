#include "Carta.h"

Carta::Carta()
{

}

Carta::Carta(int color , char* nombre)
{
    this->color = color;
    this->nombre = nombre;
}

Carta::Carta(int xArr,int yArr,char* nombre,int color)
/*
Constructor que se utiliza cuando se necesita crear un boton
*/
{
    this->xArr = xArr;
    this->yArr = yArr;
    this->xAba = xArr + 60;
    this->yAba = yArr + 60;
    this->color = color;
    this->nombre = nombre;
}

void Carta::setxArr(int posx)
{
    this->xArr = posx;
    this->xAba = posx + 60;
}

void Carta::setyArr(int posy)
{
    this->yArr = posy;
    this->yAba = posy + 60;
}


void Carta::setColorNombre(int color,char* nombre)
{
    this->color = color;
    this->nombre = nombre;
}

int Carta::getxArr()
{
    return xArr;
}


int Carta::getyArr()
{
    return yArr;
}


int Carta::getxAba()
{
    return xAba;
}


int Carta::getyAba()
{
    return yAba;
}

char* Carta::getNombre()
{
    return this->nombre;
}

int Carta::getColor()
{
    return this->color;
}

void Carta::dibujar()
/*
Metodo que dibuja una carta en pantalla
*/
{
    settextjustify(1, 1);
    settextstyle(4, 0, 1);
    setfillstyle(15,15);
    setcolor(this->color);
    rectangle(this->xArr, this->yArr, this->xAba, this->yAba);
    outtextxy(this->xArr+30, this->yArr+30, nombre);

}

Carta::~Carta()
{

}
