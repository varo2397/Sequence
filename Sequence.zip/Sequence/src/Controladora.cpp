#include "Controladora.h"

Controladora::Controladora()
{
    //ArrayStack<Carta> mazo(100);
    mazo = new ArrayStack<Carta>(100);
    cantidadJugadores = 0;
}

void Controladora::menu()
{
    initwindow(1280, 700);
    setbkcolor(15);
    cleardevice();
    //Pone el nombre del juego
    settextstyle(3,HORIZ_DIR,30);
    setcolor(3);
    outtextxy(250,100,"Sequence");

    //Pone los botones para la cantidad de jugadores
    Boton boton(520,270,"2 Jugadores",3,159);
    Boton boton1(520,340,"3 Jugadores",3,159);
    Boton boton2(520,410,"4 Jugadores",3,159);
    boton2.dibujar();
    boton1.dibujar();
    boton.dibujar();
    bool menu = false;
    int ratonx,ratony;
    while (!menu) //ciclo que se utiliza para la escogencia de la acntidad de jugadores
    {
        delay(10);

        if(ismouseclick(WM_LBUTTONDOWN))
        {

            ratonx = mousex();
            ratony = mousey();
            if(boton.getxArr() <= ratonx && ratonx <= boton.getxAba() && boton.getyArr() <= ratony && ratony <= boton.getyAba() )
            {
                cleardevice();
                menu = true;
                cantidadJugadores = 2;
                //getch();
            }
            if(boton1.getxArr() <= ratonx && ratonx <= boton1.getxAba() && boton1.getyArr() <= ratony && ratony <= boton1.getyAba() )
            {
                cleardevice();
                menu = true;
                cantidadJugadores = 3;
                //getch();
            }
            if(boton2.getxArr() <= ratonx && ratonx <= boton2.getxAba() && boton2.getyArr() <= ratony && ratony <= boton2.getyAba() )
            {
                cleardevice();
                menu = true;
                cantidadJugadores = 4;
                //getch();
            }
            int resetx;
            int resety;
            getmouseclick(WM_LBUTTONDOWN,resetx,resety);


        }
    }


    bool inst = false;
    settextstyle(3,HORIZ_DIR,7);
    setcolor(3);
    outtextxy(250,100,"Instrucciones");

    //msg += \n";
    //msg += "\n";
    //msg += "\n";
    //msg += "\n";
    //msg += "\n";
    //msg += "\n";

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(650,200,"El juego consiste en la creaci�n de una secuencia de fichas; las cuales deben formar una fila de 5 fichas del");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(395,230,"mismo color, ya sea de forma horizontal, vertical o diagonal.");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(581,270,"La cantidad de cartas por cada jugador y los equipos depender�n de la cantidad de jugadores:");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(295,310,"Para 2 jugadores -> 7 cartas -> individual");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(295,340,"Para 3 jugadores -> 6 cartas -> individual");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(285,370,"Para 4 jugadores -> 5 cartas -> parejas");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(650,410,"Existen cartas especiales que son las 'J�s', la cual una podr� colocar una ficha donde se desee en el tablero");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(434,440,"y la otra permite quitar una de las fichas del adversario del tablero.");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(643,480,"Existen tambi�n cuadros de bonus los cuales son las 4 esquinas del tablero, ya que permiten completar la");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(285,510,"secuencia de 5 ficha autom�ticamente.");

    getch();
    /*while(!inst) // Ciclo para desplegar las instrucciones
    {


    }
    */
    cleardevice();

}

void Controladora::juego()
{

    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            Carta carta(60*j+30,60*i+30);
            matriz[j][i] = carta;
        }
    }

    getch();

}

Controladora::~Controladora()
{
    //dtor
}
