#include "Controladora.h"

Controladora::Controladora()
{
    rand = new Boton(700,25,"Random",2,160);
    mazo = new ArrayStack<Carta>(150);
    cantidadJugadores = 0;
    tablero = new Matriz();
}

void Controladora::menu()
{
    initwindow(1280,700,"Sequence");
    setbkcolor(15);
    cleardevice();
    //Pone el nombre del juego
    settextstyle(3,HORIZ_DIR,30);
    setcolor(3);
    outtextxy(250,100,"Sequence");

    //Pone los botones para la cantidad de jugadores
    Boton boton(520,270,"2 Jugadores",3,159);
    Boton boton1(520,340,"3 Jugadores",3,159);
    Boton boton2(520,410,"4 Jugadores",3,159);
    boton2.dibujar();
    boton1.dibujar();
    boton.dibujar();
    bool menu = false;
    int ratonx,ratony;
    while (!menu) //ciclo que se utiliza para la escogencia de la acntidad de jugadores
    {
        delay(10);

        if(ismouseclick(WM_LBUTTONDOWN))
        {

            ratonx = mousex();
            ratony = mousey();
            if(boton.getxArr() <= ratonx && ratonx <= boton.getxAba() && boton.getyArr() <= ratony && ratony <= boton.getyAba() )
            {
                cleardevice();
                menu = true;
                cantidadJugadores = 2;
                //getch();
            }
            else if(boton1.getxArr() <= ratonx && ratonx <= boton1.getxAba() && boton1.getyArr() <= ratony && ratony <= boton1.getyAba() )
            {
                cleardevice();
                menu = true;
                cantidadJugadores = 3;
                //getch();
            }
            else if(boton2.getxArr() <= ratonx && ratonx <= boton2.getxAba() && boton2.getyArr() <= ratony && ratony <= boton2.getyAba() )
            {
                cleardevice();
                menu = true;
                cantidadJugadores = 4;
                //getch();
            }
            int resetx;
            int resety;
            getmouseclick(WM_LBUTTONDOWN,resetx,resety);


        }
    }


    bool inst = false;
    settextstyle(3,HORIZ_DIR,7);
    setcolor(3);
    outtextxy(250,100,"Instrucciones");

    getch();
    /*while(!inst) // Ciclo para desplegar las instrucciones
    {


    }
    */
    cleardevice();

}

void Controladora::juego()
{

    dibujar();
    mazo->ingresar(tablero);
    cout<<mazo->getSize();
    bool game = false;
    int ratonx,ratony;

    while(!game)
    {
        delay(10);

        if(ismouseclick(WM_LBUTTONDOWN))
        {
            ratonx = mousex();
            ratony = mousey();

            if(rand->getxArr() <= ratonx && ratonx <= rand->getxAba() && rand->getyArr() <= ratony && ratony <= rand->getyAba())
            {
                tablero->aleatorio();
                dibujar();
            }
            int resetx;
            int resety;
            getmouseclick(WM_LBUTTONDOWN,resetx,resety);
        }
    }

    //getch();
}

void Controladora::dibujar()
{
    cleardevice(); //para que no se sobrepongan las letras
    rand->dibujar();
    tablero->mostrar(); //se vuelve a dibujar el tablero
}



Controladora::~Controladora()
{
    //dtor
}
