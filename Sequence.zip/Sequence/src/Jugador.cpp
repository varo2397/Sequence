#include "Jugador.h"

Jugador::Jugador()
{

}

Jugador::Jugador(int cantCartas, int color,char* nombre)
{
    //ctor
    this->color = color;
    this->nombre = nombre;
    listaCartas = new CArrayList<Carta>(cantCartas);
}

int Jugador::getColor()
// Metodo que retorna el color de las cartas del jugador actual
{
    return this->color;
}

void Jugador::append(Carta elemento)
//Metodo que inserta al final de la lista de cartas una carta
//Entradas:
//    Carta elemento: un objeto de tipo carta
{
    listaCartas->append(elemento);
}

void Jugador::dibujar()
//Metodo que dibuja en el area de juego las cartas actuales
{
    listaCartas->goToStart();
    for (int i = 0; i < listaCartas->getSize(); i++) //Se recorre la lista de cartas
    {
        listaCartas->returnValue().setxArr((i+12) * 60); // Se establecen las posiciones
        listaCartas->returnValue().setyArr(300);
        listaCartas->returnValue().setColor(this->color); //Se establece el color que va a ser el mismo que el del jugador
        listaCartas->returnValue().dibujar(); //Se dibujan las cartas una por una
        listaCartas->next(); //Se usa la siguiente carta en el proximo ciclo
    }
}

bool Jugador::verificarPosicion(int x,int y)
//Metodo que verifica si en determinadas posiciones x,y de la pantalla
//se hizo un click en una carta del jugador
//Entradas:
//    x: posicion en el eje x de del click dado
//    y: posicion en el eje y del click dado
//Salidas:
//    true si el click se dio dentro de alguna Carta
//    false si el click no se dio dentro de alguna carta
{
    listaCartas->goToStart(); //Se va al inicio de la lista de cartas
    bool clickCarta = false; //Variale que se va a utilizar para retornar
    for (int i = 0; i < listaCartas->getSize(); i++) //Se recorre la lista de cartas
    {
        if((listaCartas->getValue().getxArr() <= x && x <= listaCartas->getValue().getxAba()
            && listaCartas->getValue().getyArr() <= y && y <= listaCartas->getValue().getyAba())) //Se obtiene la posicion de cada carta y se verifica si esta dentro de los limites
           {
               clickCarta = true; //Se cambia el valor de la variable
               break; //Se termina el ciclo ya que se encontro una carta con esas coordenadas
           }
        listaCartas->next(); //Se busca en la siguiente carta de la lista
    }
    return clickCarta; //Se retorna el valor
}

//void Jugador::setPos()
//
//{
//    listaCartas->goToStart();
//    for (int i = 0; i < listaCartas->getSize(); i++)
//    {
//        listaCartas->returnValue().setPosicion(i); //Se pone cada valor dependiendo del indice donde este
//        listaCartas->next();
//    }
//}

Carta& Jugador::retornarCarta(int x,int y)
//Metodo que busca entre las cartas del jugador por las coordenadas que se reciben
//Entradas:
//    x: posicion en el eje x
//    y: posicion en el eje y
//Salidas:
//    Se retorna la direccion de la carta que se estaba buscando
{
    listaCartas->goToStart();

    for (int i = 0; i < listaCartas->getSize(); i++)
    {
        if((listaCartas->getValue().getxArr() <= x && x <= listaCartas->getValue().getxAba() \
            && listaCartas->getValue().getyArr() <= y && y <= listaCartas->getValue().getyAba()))
           {
               Carta &clickCarta = listaCartas->returnValue();
               return clickCarta;
           }
        listaCartas->next();
    }

}

void Jugador::cambiarColor(int x,int y)

{
    listaCartas->goToStart();
    bool clickCarta = false;
    for (int i = 0; i < listaCartas->getSize(); i++)
    {
        if((listaCartas->getValue().getxArr() <= x && x <= listaCartas->getValue().getxAba() \
            && listaCartas->getValue().getyArr() <= y && y <= listaCartas->getValue().getyAba()))
           {
               listaCartas->getValue().setColor(5);
               break;
           }
        listaCartas->next();
    }
}

void Jugador::asignarPos()
//Metodo que pone los valores de los indices para cada Carta
{
    listaCartas->goToStart();
    for(int i = 0; i < listaCartas->getSize(); i++)
    {
        listaCartas->returnValue().setPosicion(i);
        listaCartas->next();
    }
}

char* Jugador::getNombre()
//Metodo que retorna el nombre del jugador
//Salidas:
//    Se retorna el arreglo de caracteres del nombre del jugador
{
        return this->nombre;
}

Carta Jugador::insertar(Carta elemento,int posicion)
//Metodo que mete una carta nueva a la mano del jugador y borra la anterior
//Entradas:
//    Carta elemento: carta nueva que se va a ingresar
//    int posicion: indice por el cual se va a cambiar la carta nueva y borrar la vieja
//Salidas:
//    Retorna la carta que se esta eliminando de la mano del jugador
{

    Carta temp = listaCartas->remove(posicion);//se remueve el valor que se quiere eliminar y ademas se guarda el mismo
    listaCartas->insert(posicion, elemento);//se inserta el nuevo elemento
    return temp;
}
Jugador::~Jugador()
{
    //dtor
}
