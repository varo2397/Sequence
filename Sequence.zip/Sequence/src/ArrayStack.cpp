#include "ArrayStack.h"
#include <stdexcept>

using namespace std;
template <class E>
ArrayStack<E>::ArrayStack(int maxSize):ArrayList<E>::ArrayList(maxSize)
{
    //this->max = maxSize;
    //this->size = 0;
    //this->pos = 0;
    //this->elements = new int[maxSize];
    //ArrayList<E>::ArrayList(maxSize);

}

template <class E>
void ArrayStack<E>:: push(E element)
{
    if (this->size == this->max)
    {

        throw runtime_error("La pila esta llena");
    }
    this->pos = this->size - 1;
    this->top = this->size - 1;
    ArrayList<E>::insert(element,this->pos);


}
template <class E>
void ArrayStack<E>:: pop()
{
    if (this->size == 0)
    {
        throw runtime_error("La pila esta vacia");
    }
    this->pos = this->size - 1;
    ArrayList<E>::remove(this->pos);
    this->pos = this->size - 1;
    this->top = this->size - 1;

}
template <class E>
E ArrayStack<E>::topValue()
{
    return this->elements[top];
}
template <class E>
void ArrayStack<E>::clear()
{
    this->size = 0;
    this->pos = 0;
    delete []this->elements;
    this->top = 0;
}

template <class E>
void ArrayStack<E>::ingresar(Matriz* matriz)
{
    for(int i = 0; i < 10; i++)
    {
        for(int j = 0; j < 10; j++)
        {
            //Se verifica que no se metan los comodines
            if(i == 0 && j == 0)
            {

            }
            else if(i == 0 && j == 9)
            {

            }
            else if(i == 9 && j == 0)
            {

            }
            else if(i == 9 && j == 9)
            {

            }
            else // caso regular
            {
                push(matriz->getValor(i,j));
            }

        }
    }
    cout<<"termina ciclo";
    int magenta = 5;
    push(Carta(magenta,"J1E"));

    push(Carta(magenta,"J1E"));

    push(Carta(magenta,"J1C"));

    push(Carta(magenta,"J1C"));

    push(Carta(magenta,"J2T"));

    push(Carta(magenta,"J2T"));

    push(Carta(magenta,"J2D"));

    push(Carta(magenta,"J2D"));
    cout<<"termina metodo";
}

template <class E>
ArrayStack<E>::~ArrayStack()
{
    clear();
}

//template class ArrayStack<Carta>
//template class ArrayStack<int>;
template class ArrayStack<Carta>;
