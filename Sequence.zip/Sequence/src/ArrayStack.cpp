#include "ArrayStack.h"
#include <stdexcept>

using namespace std;
template <class E>
ArrayStack<E>::ArrayStack(int maxSize):ArrayList<E>::ArrayList(maxSize)
{
    //this->max = maxSize;
    //this->size = 0;
    //this->pos = 0;
    //this->elements = new int[maxSize];
    //ArrayList<E>::ArrayList(maxSize);

}

template <class E>
void ArrayStack<E>:: push(E element)
{
    if (this->size == maxSize)
    {
        throw runtime_error("La pila esta llena");
    }
    this->pos = this->size - 1;
    this->top = this->size - 1;
    ArrayList<E>::insert(element,this->pos);

}
template <class E>
void ArrayStack<E>:: pop()
{
    if (this->size == 0)
    {
        throw runtime_error("La pila esta vacia");
    }
    this->pos = this->size - 1;
    ArrayList<E>::remove(this->pos);
    this->pos = this->size - 1;
    this->top = this->size - 1;

}
template <class E>
E ArrayStack<E>::topValue()
{
    return this->elements[top];
}
template <class E>
void ArrayStack<E>::clear()
{
    this->size = 0;
    this->pos = 0;
    delete []this->elements;
    this->top = 0;
}
template <class E>
ArrayStack<E>::~ArrayStack()
{
    clear();
}
//template class ArrayStack<Carta>
template class ArrayStack<int>;
template class ArrayStack<Carta>;
