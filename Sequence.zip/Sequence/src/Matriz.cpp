#include "Matriz.h"

Matriz::Matriz()
{
    //ciclo para crear todos los objetos Carta
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {

            matriz[j][i] = Carta();
        }
    }

    int azul = 1;
    int rojo  = 4;
    int negro = 0;
    //Primera fila de cartas
    matriz[0][0].setColorNombre(azul,"*");
    matriz[0][1].setColorNombre(negro,"10E");
    matriz[0][2].setColorNombre(negro,"QE");
    matriz[0][3].setColorNombre(negro,"KE");
    matriz[0][4].setColorNombre(negro,"AE");
    matriz[0][5].setColorNombre(rojo,"2D");
    matriz[0][6].setColorNombre(rojo,"3D");
    matriz[0][7].setColorNombre(rojo,"4D");
    matriz[0][8].setColorNombre(rojo,"5D");
    matriz[0][9].setColorNombre(azul,"*");

    //Segunda fila
    matriz[1][0].setColorNombre(negro,"9E");
    matriz[1][1].setColorNombre(rojo,"10C");
    matriz[1][2].setColorNombre(rojo,"9C");
    matriz[1][3].setColorNombre(rojo,"8C");
    matriz[1][4].setColorNombre(rojo,"7C");
    matriz[1][5].setColorNombre(rojo,"6C");
    matriz[1][6].setColorNombre(rojo,"5C");
    matriz[1][7].setColorNombre(rojo,"4C");
    matriz[1][8].setColorNombre(rojo,"3C");
    matriz[1][9].setColorNombre(rojo,"6D");

    //tercera fila
    matriz[2][0].setColorNombre(negro,"8E");
    matriz[2][1].setColorNombre(rojo,"QC");
    matriz[2][2].setColorNombre(rojo,"7D");
    matriz[2][3].setColorNombre(rojo,"8D");
    matriz[2][4].setColorNombre(rojo,"9D");
    matriz[2][5].setColorNombre(rojo,"10D");
    matriz[2][6].setColorNombre(rojo,"QD");
    matriz[2][7].setColorNombre(rojo,"KD");
    matriz[2][8].setColorNombre(rojo,"2C");
    matriz[2][9].setColorNombre(rojo,"7D");

    //cuarta fila
    matriz[3][0].setColorNombre(negro,"7E");
    matriz[3][1].setColorNombre(rojo,"KC");
    matriz[3][2].setColorNombre(rojo,"6D");
    matriz[3][3].setColorNombre(negro,"2T");
    matriz[3][4].setColorNombre(rojo,"AC");
    matriz[3][5].setColorNombre(rojo,"KC");
    matriz[3][6].setColorNombre(rojo,"QC");
    matriz[3][7].setColorNombre(rojo,"AD");
    matriz[3][8].setColorNombre(negro,"2E");
    matriz[3][9].setColorNombre(rojo,"8D");

    //quinta fila
    matriz[4][0].setColorNombre(negro,"6E");
    matriz[4][1].setColorNombre(rojo,"AC");
    matriz[4][2].setColorNombre(rojo,"5D");
    matriz[4][3].setColorNombre(negro,"3T");
    matriz[4][4].setColorNombre(rojo,"4C");
    matriz[4][5].setColorNombre(rojo,"3C");
    matriz[4][6].setColorNombre(rojo,"10C");
    matriz[4][7].setColorNombre(negro,"AT");
    matriz[4][8].setColorNombre(negro,"3E");
    matriz[4][9].setColorNombre(rojo,"9D");

    //sexta fila
    matriz[5][0].setColorNombre(negro,"5E");
    matriz[5][1].setColorNombre(negro,"2T");
    matriz[5][2].setColorNombre(rojo,"4D");
    matriz[5][3].setColorNombre(negro,"4T");
    matriz[5][4].setColorNombre(rojo,"5C");
    matriz[5][5].setColorNombre(rojo,"2C");
    matriz[5][6].setColorNombre(rojo,"9C");
    matriz[5][7].setColorNombre(negro,"KT");
    matriz[5][8].setColorNombre(negro,"4E");
    matriz[5][9].setColorNombre(rojo,"10D");

    //setima fila
    matriz[6][0].setColorNombre(negro,"4E");
    matriz[6][1].setColorNombre(negro,"3T");
    matriz[6][2].setColorNombre(rojo,"3D");
    matriz[6][3].setColorNombre(negro,"5T");
    matriz[6][4].setColorNombre(rojo,"6C");
    matriz[6][5].setColorNombre(rojo,"7C");
    matriz[6][6].setColorNombre(rojo,"8D");
    matriz[6][7].setColorNombre(negro,"QT");
    matriz[6][8].setColorNombre(negro,"5E");
    matriz[6][9].setColorNombre(rojo,"QD");

    //octava fila
    matriz[7][0].setColorNombre(negro,"3E");
    matriz[7][1].setColorNombre(negro,"4T");
    matriz[7][2].setColorNombre(rojo,"2D");
    matriz[7][3].setColorNombre(negro,"6T");
    matriz[7][4].setColorNombre(negro,"7T");
    matriz[7][5].setColorNombre(negro,"8T");
    matriz[7][6].setColorNombre(negro,"9T");
    matriz[7][7].setColorNombre(negro,"10T");
    matriz[7][8].setColorNombre(negro,"6E");
    matriz[7][9].setColorNombre(rojo,"KD");

    //novena fila
    matriz[8][0].setColorNombre(negro,"2E");
    matriz[8][1].setColorNombre(negro,"5T");
    matriz[8][2].setColorNombre(negro,"AE");
    matriz[8][3].setColorNombre(negro,"KE");
    matriz[8][4].setColorNombre(negro,"QE");
    matriz[8][5].setColorNombre(negro,"10E");
    matriz[8][6].setColorNombre(negro,"9E");
    matriz[8][7].setColorNombre(negro,"8E");
    matriz[8][8].setColorNombre(negro,"7E");
    matriz[8][9].setColorNombre(rojo,"AD");

    //decima fila
    matriz[9][0].setColorNombre(azul,"*");
    matriz[9][1].setColorNombre(negro,"6T");
    matriz[9][2].setColorNombre(negro,"7T");
    matriz[9][3].setColorNombre(negro,"8T");
    matriz[9][4].setColorNombre(negro,"9T");
    matriz[9][5].setColorNombre(negro,"10T");
    matriz[9][6].setColorNombre(negro,"QT");
    matriz[9][7].setColorNombre(negro,"KT");
    matriz[9][8].setColorNombre(negro,"AT");
    matriz[9][9].setColorNombre(azul,"*");
}

void Matriz::mostrar()
{
    for (int i = 0;i < 10;i++)
    {
        for (int j = 0;j < 10;j++)
        {
            matriz[j][i].setxArr(60*j+10);
            matriz[j][i].setyArr(60*i+10);
            matriz[j][i].dibujar();
        }
    }
}

void Matriz::aleatorio()
//Metodo que hace los cambiso necesarios para
//que se ordene de forma aleatoria la Matriz
{
    for (int i = 0;i < 100;i++)
    {
        int posx1 = rand() % 10;
        int posy1 = rand() % 10;

        int posx2 = rand() % 10;
        int posy2 = rand() % 10;

        // casos en los que se quisieran cambiar las esquinas
        if ((posx1 == 0 && posy1 == 0) || (posx2 == 0 && posy2 == 0))
        {

        }
        else if ((posx1 == 0 && posy1 == 9)|| (posx2 == 0 && posy2 == 9))
        {

        }
        else if ((posx1 == 9 && posy1 == 0) || (posx2 == 9 && posy2 == 0))
        {

        }
        else if ((posx1 == 9 && posy1 == 9) || (posx2 == 9 && posy2 == 9))
        {

        }
        else // caso en el que se debe hacer el cambio
        {
            int colorTemp = matriz[posx1][posy1].getColor();
            char* nombreTemp = matriz[posx1][posy1].getNombre();

            matriz[posx1][posy1].setColorNombre(matriz[posx2][posy2].getColor(),matriz[posx2][posy2].getNombre());

            matriz[posx2][posy2].setColorNombre(colorTemp,nombreTemp);
        }

    }
}

Carta Matriz::getValor(int posx,int posy)
{
    return this->matriz[posx][posy];
}

Matriz::~Matriz()
{
    //dtor
}
