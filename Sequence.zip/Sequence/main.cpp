#include <iostream>
#include "winbgim.h"
//#include "graphics.h"
#include "Controladora.h"
#include <io.h>
#include <fcntl.h>
using namespace std;

int main()
{

    Controladora control;

    control.menu();
    control.juego();
    return 0;
}
