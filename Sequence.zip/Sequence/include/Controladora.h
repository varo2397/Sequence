#ifndef CONTROLADORA_H
#define CONTROLADORA_H
#include "Carta.h"
#include "Boton.h"
#include "ArrayStack.h"
#include "Matriz.h"
#include "graphics.h"
#include <iostream>
class Controladora
{
    public:
        Controladora();
        void menu();
        void juego();
        void dibujar();
        void meterStack();
        virtual ~Controladora();

    protected:

    private:
        Boton* rand;
        int cantidadJugadores; //atributo que va a contener la cantidad de jugadires
        ArrayStack<Carta>* mazo; // atributo que es el mazo del juego
        Matriz* tablero;
        //Carta matriz[10][10]; // atributo que es la matriz con todas las cartas
};

#endif // CONTROLADORA_H
