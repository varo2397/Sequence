#ifndef CONTROLADORA_H
#define CONTROLADORA_H
#include "Carta.h"
#include "Boton.h"
#include "ArrayStack.h"
#include "Matriz.h"
#include "Jugador.h"
#include "CArrayList.h"
#include "graphics.h"
#include "cstddef"
#include <iostream>
#include <io.h>
#include <fcntl.h>
class Controladora
{
    public:
        Controladora();
        void menu();
        void resetMouse();
        void juego();
        void dibujar();
        void barajar();
        virtual ~Controladora();

    protected:
        CArrayList<Jugador>* jugadores;
    private:

        Boton* rand; //Boton random
        int cantidadJugadores; //Cantidad de jugadores deseados por el usuario
        ArrayStack<Carta>* mazo; //Mazo del cual se sacan las cartas para los jugadores
        ArrayStack<Carta>* mazoDescarte; //Mazo de las cartas que han sido utilizadas
        Matriz* tablero; //Matriz con todas las cartas
};

#endif // CONTROLADORA_H
