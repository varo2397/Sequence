#ifndef CARTA_H
#define CARTA_H
#include "winbgim.h"
#include <string>
#include <iostream>
#include <stdio.h>

using namespace std;

class Carta
{
    public:
        Carta();
        Carta(int xArr,int yArr,char* nombre,int color); // constructor para crear los botones
        Carta(int xArr,int yArr); // constructor para poder poner posiciones y no tener meterlas a mano

        void dibujar();

        int getxArr();
        int getyArr();

        int getxAba();
        int getyAba();

        void setxArr(int posx);
        void setyArr(int posy);

        void setxAba(int posx);
        void setyAba(int posy);

        void setColor(int color);
        void setName(char* nombre);
        virtual ~Carta();

    protected:
        int xArr;
        int yArr;
        int xAba;
        int yAba;
        int color;
        char* nombre;
    private:

};

#endif // CARTA_H
