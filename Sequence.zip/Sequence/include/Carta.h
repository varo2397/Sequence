#ifndef CARTA_H
#define CARTA_H
#include "graphics.h"
#include <string>
#include <iostream>
#include <stdio.h>

using namespace std;

class Carta
{
    public:
        Carta();
        Carta(int color,char* nombre);
        Carta(int xArr,int yArr,char* nombre,int color); // constructor para crear los botones

        void dibujar();

        int getxArr();
        int getyArr();

        int getxAba();
        int getyAba();

        void setxArr(int posx);
        void setyArr(int posy);

        void setColorNombre(int color,char* nombre);
        char* getNombre();
        int getColor();

        virtual ~Carta();

    protected:
        int xArr;
        int yArr;
        int xAba;
        int yAba;
        int color;
        char* nombre;
    private:

};

#endif // CARTA_H
