#ifndef CARTA_H
#define CARTA_H
#include "graphics.h"
#include <iostream>
#include <cstddef>
#include <stdio.h>

using namespace std;

class Carta
{
    public:
        Carta();
        Carta(int color,char* nombre);
        Carta(int xArr,int yArr,char* nombre,int color); // constructor para crear los botones

        void dibujar();

        int getxArr();
        int getyArr();

        int getxAba();
        int getyAba();

        void setxArr(int posx);
        void setyArr(int posy);

        void setNombreJugador(char* nombre);
        void setColorNombre(int color,char* nombre);
        void setColor(int color);
        void setNombre(char* nombre);
        char* getNombre();
        int getColor();
        int getPosicion();
        void setFicha(bool cambio);
        void setColorFicha(int color);
        void setPosicion(int posicion);
        virtual ~Carta();

    protected:
        int xArr;
        int yArr;
        int xAba;
        int yAba;
        int color;
        char* nombre;
        char* nombreJugador;
        bool ficha;
        int colorFicha;
        int posicion;
    private:

};

#endif // CARTA_H
