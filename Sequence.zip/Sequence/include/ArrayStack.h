#ifndef ARRAYSTACK_H
#define ARRAYSTACK_H
#include "ArrayList.h"

#include "Matriz.h"
#include "stdlib.h"
#include <iostream>
template <class E>
class ArrayStack: public ArrayList<E>
{
    public:
        ArrayStack(int maxSize);
        E topValue();
        void push(E element);
        E pop();
        void dibujarTop();
        void mezclar();
        void ingresar(Matriz* matriz);
        void clear();
        ~ArrayStack();

    protected:
        int maxSize;
        int top;
        int xArr;
        int yArr;
        int xAba;
        int yAba;
    private:
};

#endif // ARRAYSTACK_H
