#ifndef ARRAYSTACK_H
#define ARRAYSTACK_H
#include "ArrayList.h"
#include "Carta.h"
template <class E>
class ArrayStack: public ArrayList<E>
{
    public:
        ArrayStack(int maxSize);
        E topValue();
        void push(E element);
        void pop();
        void clear();
        ~ArrayStack();

    protected:
        int maxSize;
        int top;
    private:
};

#endif // ARRAYSTACK_H
