#ifndef CARRAYLIST_H
#define CARRAYLIST_H
using namespace std;

template <class E>

class CArrayList
{
    public:
        CArrayList();
        CArrayList(int pMax); //Constructor
        virtual ~CArrayList(); //Destructor
        void setArraySize(int size);
        E getValue();
        E& returnValue();
        int getPos();
        int getSize();
        void goToStart();
        void goToEnd();
        void goToPos(int pos);
        void previous();
        void next();
        void append(E pElement);
        void insert(int pos, E pElement);
        E remove(int pos);
        //void print();

    protected:
        int size; //tama�o
        int max; //maximo de la lista
        int pos; //posicion de la lista
        E* elements;
};

#endif // CARRAYLIST_H
