#ifndef ARRAYLIST_H
#define ARRAYLIST_H
#include <stdexcept>
#include "Carta.h"

template<class E>
class ArrayList
{
    public:
        ArrayList();
        ArrayList(int pMax);
        ~ArrayList();
        E getValue();
        int getPos();
        int getSize();
        void goToStart();
        void goToEnd();
        void goToPos();
        void previous();
        void next();
        void append(E pElement);
        void goToPos(int pos);
        void insert(E pElement,int pos);
        E remove(int pos);
        void print();

    protected:
        int size; //tama�o
        int max; //maximo de la lista
        int pos; //posicion de la lista
        E* elements;

    private:

};

#endif // ARRAYLIST_H
