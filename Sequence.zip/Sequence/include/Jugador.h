#ifndef JUGADOR_H
#define JUGADOR_H
#include "CArrayList.h"
#include "Carta.h"
#include "Matriz.h"
#include "graphics.h"
#include "stdlib.h"
#include "cstddef"

class Jugador
{
    public:
        Jugador();
        Jugador(int cantCartas,int color,char* nombre);
        int getColor();
        void setColor(int color);
        void setCantCartas(int cantCartas);
        void append(Carta elemento);
        Carta insertar(Carta elemento,int posicion);
        void dibujar();
        void setPos();
        char* getNombre();
        void asignarPos();
        void cambiarColor(int x, int y);
        Carta &retornarCarta(int x,int y);
        bool verificarPosicion(int x, int y);
        virtual ~Jugador();


    protected:

    private:
        int color; //Color de las cartas y fichas del jugador
        char* nombre; //Nombre del jugador
        CArrayList<Carta>* listaCartas; //Lista de cartas del jugador

};

#endif // JUGADOR_H
