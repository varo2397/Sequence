#include "ArrayStack.h"
#include <stdexcept>

const int posicionX = 700;
const int posicionY = 100;

using namespace std;
template <class E>
ArrayStack<E>::ArrayStack(int maxSize):ArrayList<E>::ArrayList(maxSize)
{
    //this->max = maxSize;
    //this->size = 0;
    //this->pos = 0;
    //this->elements = new int[maxSize];
    //ArrayList<E>::ArrayList(maxSize);
    this->xArr = posicionX;
    this->yArr = posicionY;
    this->xAba = posicionX + 60;
    this->yAba = posicionY + 60;

}

template <class E>
void ArrayStack<E>:: push(E element)
{
    if (this->size == this->max)
    {

        throw runtime_error("La pila esta llena");
    }
    this->pos = this->size - 1;
    this->top = this->size - 1;
    ArrayList<E>::insert(element,this->pos);


}
template <class E>
E ArrayStack<E>:: pop()
{
    if (this->size == 0)
    {
        throw runtime_error("La pila esta vacia");
    }
    E temp;
    this->pos = this->size - 1;
    temp = ArrayList<E>::remove(this->pos);
    this->pos = this->size - 1;
    this->top = this->size - 1;
    return temp;

}
template <class E>
E ArrayStack<E>::topValue()
{
    return this->elements[top];
}
template <class E>
void ArrayStack<E>::clear()
{
    this->size = 0;
    this->pos = 0;
    delete []this->elements;
    this->top = 0;

}

template <class E>
void ArrayStack<E>::mezclar()
{
    E temp;
    int pos1;
    int pos2;
    //srand(time(0));
    for (int i = 0; i < this->size; i++)
    {
        pos1 = rand() % this->size;
        pos2 = rand() % this->size;
        temp = this->elements[pos1];
        this->elements[pos1] = this->elements[pos2];
        this->elements[pos2] = temp;
    }

}

template <class E>
void ArrayStack<E>::ingresar(Matriz* matriz)
{
    for(int i = 0; i < 10; i++)
    {
        for(int j = 0; j < 10; j++)
        {
            //Se verifica que no se metan los comodines
            if(i == 0 && j == 0)
            {

            }
            else if(i == 0 && j == 9)
            {

            }
            else if(i == 9 && j == 0)
            {

            }
            else if(i == 9 && j == 9)
            {

            }
            else // caso regular
            {
                push(matriz->getValor(i,j));
            }

        }
    }
    int magenta = 5;
    push(Carta(magenta,"J1E"));

    push(Carta(magenta,"J1E"));

    push(Carta(magenta,"J1C"));

    push(Carta(magenta,"J1C"));

    push(Carta(magenta,"J2T"));

    push(Carta(magenta,"J2T"));

    push(Carta(magenta,"J2D"));

    push(Carta(magenta,"J2D"));

}

template <class E>
void ArrayStack<E>::dibujarTop()
{
    if(this->top == 0)
    {
        setcolor(13);
        rectangle(this->xArr, this->yArr, this->xAba, this->yAba);
    }
    else
    {
        this->elements[this->top].setxArr(this->xArr);
        this->elements[this->top].setyArr(this->yArr);
        this->elements[this->top].setColor(13);
        this->elements[this->top].dibujar();
    }

}

template <class E>
ArrayStack<E>::~ArrayStack()
{
    clear();
}

//template class ArrayStack<Carta>
//template class ArrayStack<int>;
template class ArrayStack<Carta>;
