#include "Carta.h"

Carta::Carta()
{
    this->ficha = false;
    this->nombreJugador = NULL;
}

Carta::Carta(int color , char* nombre)
{
    this->color = color;
    this->nombre = nombre;
    this->ficha = false;
    this->nombreJugador = NULL;
}

Carta::Carta(int xArr,int yArr,char* nombre,int color)
/*
Constructor que se utiliza cuando se necesita crear un boton
*/
{
    this->xArr = xArr;
    this->yArr = yArr;
    this->xAba = xArr + 60;
    this->yAba = yArr + 60;
    this->color = color;
    this->nombre = nombre;
    this->ficha = false;
}

void Carta::setxArr(int posx)
{
    this->xArr = posx;
    this->xAba = posx + 60;
}

bool Carta::getFicha()
{
    return this->ficha;
}

void Carta::setyArr(int posy)
{
    this->yArr = posy;
    this->yAba = posy + 60;
}

void Carta::setFicha(bool cambio)
{
    ficha = cambio;
}

void Carta::setColorNombre(int color,char* nombre)
{
    setColor(color);
    setNombre(nombre);
}

void Carta::setPosicion(int posicion)
//Metodo que pone la posicion en una lista de la carta
{
    this->posicion = posicion;
}

void Carta::setColorFicha(int color)
{
    colorFicha = color;
}

void Carta::setNombreJugador(char* jugador)
{
    this->nombreJugador = jugador;
}

int Carta::getxArr()
{
    return xArr;
}


int Carta::getyArr()
{
    return yArr;
}


int Carta::getxAba()
{
    return xAba;
}


int Carta::getyAba()
{
    return yAba;
}

char* Carta::getNombre()
{
    return this->nombre;
}

int Carta::getColor()
{
    return this->color;
}

void Carta::setNombre(char* nombre)
{
    this->nombre = nombre;
}

void Carta::setColor(int color)
{
    this->color = color;
}

int Carta::getPosicion()
{
    return this->posicion;
}

void Carta::dibujar()
/*
Metodo que dibuja una carta en pantalla
*/
{
    settextjustify(1, 1);
    settextstyle(4, 0, 1);
    setfillstyle(15,15);
    setcolor(this->color);
    rectangle(this->xArr, this->yArr, this->xAba, this->yAba);
    outtextxy(this->xArr+30, this->yArr+30, nombre);
    if (ficha)
    {
        setfillstyle(this->colorFicha,this->colorFicha);
        setcolor(this->colorFicha);
        fillellipse((this->xArr + this->xAba) / 2, (this->yArr + this->yAba) / 2, 30,30);
    }

}

Carta::~Carta()
{

}
