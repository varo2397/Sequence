#include "Controladora.h"

Controladora::Controladora()
{
    rand = new Boton(1000,550,"Random",2,160);
    mazo = new ArrayStack<Carta>(104);
    mazoDescarte = new ArrayStack<Carta>(104);
    cantidadJugadores = 0;
    tablero = new Matriz();
}

void Controladora::menu()
//Metodo que dibuja en pantalla el menu donde se escoge la cantidad de jugadores
//Salidas:
//    Se crea la pantalla y el menu
{
    initwindow(1280,700,"Sequence"); //Se crea la pantalla con las dimensiones deseadas
    setbkcolor(15); //Se pone el color de fondo blanco
    cleardevice(); //Se borra todo de la pantalla para poder poner el fondo blanco

    //Pone el nombre del juego
    settextstyle(3,HORIZ_DIR,30);
    setcolor(3);
    outtextxy(250,100,"Sequence");

    //Pone los botones para la cantidad de jugadores
    Boton boton(520,270,"2 Jugadores",3,159);
    Boton boton1(520,340,"3 Jugadores",3,159);
    Boton boton2(520,410,"4 Jugadores",3,159);
    boton2.dibujar();
    boton1.dibujar();
    boton.dibujar();
    rand->dibujar();
    bool menu = false;
    int ratonx,ratony;
    while (!menu) //ciclo que se utiliza para la escogencia de la acntidad de jugadores
    {
        delay(10);

        if(ismouseclick(WM_LBUTTONDOWN)) //Se detecta un click
        {

            ratonx = mousex();
            ratony = mousey();
            //En caso de que sean 2 jugadores
            if(boton.getxArr() <= ratonx && ratonx <= boton.getxAba() && boton.getyArr() <= ratony && ratony <= boton.getyAba() )
            {
                cleardevice();
                menu = true;
                cantidadJugadores = 2;
            }
            //En caso de que sean 3 jugadores
            else if(boton1.getxArr() <= ratonx && ratonx <= boton1.getxAba() && boton1.getyArr() <= ratony && ratony <= boton1.getyAba() )
            {
                cleardevice();
                menu = true;
                cantidadJugadores = 3;
            }
            //En caso de que sean 4 jugadores
            else if(boton2.getxArr() <= ratonx && ratonx <= boton2.getxAba() && boton2.getyArr() <= ratony && ratony <= boton2.getyAba() )
            {
                cleardevice();
                menu = true;
                cantidadJugadores = 4;
            }
//            if(rand->getxArr() <= ratonx && ratonx <= rand->getxAba() && rand->getyArr() <= ratony && ratony <= rand->getyAba())
//            {
//                tablero->aleatorio(); //Se mezcla la matriz con todas las cartas
//            }
//            resetMouse();


        }
    }


    bool inst = false;
    settextstyle(3,HORIZ_DIR,7);
    setcolor(3);
    outtextxy(250,100,"Instrucciones");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(390,200,"El juego consiste en la creaci�n de una secuencia de fichas.");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(315,230,"Las cartas se identifican de la siguiente forma:");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(185,310,"E -> Espada");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(180,340,"T -> Tr�bol");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(190,370,"C -> Coraz�n");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(196,400,"D -> Diamante");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(377,480,"Existen 2 tipos de J's las cuales se identifican de la forma:");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(355,560,"J1 -> Quita una de las fichas del contrincante");

    settextstyle(3,HORIZ_DIR,3);
    setcolor(3);
    outtextxy(413,590,"J2 -> Coloca una ficha en cualquier posici�n del tablero");

    getch();
    /*while(!inst) // Ciclo para desplegar las instrucciones
    {


    }
    */
    cleardevice();


}

void Controladora::juego()
//Metodo que maneja todas las acciones del usuario para jugar
{
    //Se meten al mazo todas las cartas y ademas de mezclan
    mazo->ingresar(tablero);

    //Se mezclan de forma aleatoria todas las cartas que se van a repartir a los jugadores
    mazo->mezclar();

    //Se le da a los jugadores la cantidad de cartas que ocupen dependiendo de la cantidad de jugadores
    barajar();

    //Se dibujan todos los botones y demas cosas necesarias para el juego
    dibujar();


    bool game = false; //Variable para el ciclo infinito del juego
    int ratonx,ratony; //Variables para las posiciones del mouse

    while(!game) //Ciclo del juego
    {
        delay(10); //Delay necesario para que pueda captar un click

        if(ismouseclick(WM_LBUTTONDOWN)) //Se detecta un click
        {
            //Se obtienen los valores en donde se dio el click
            ratonx = mousex();
            ratony = mousey();

            //Se verifica si la posicion del mouse fue dentro del boton random
//            if(rand->getxArr() <= ratonx && ratonx <= rand->getxAba() && rand->getyArr() <= ratony && ratony <= rand->getyAba())
//            {
//                tablero->aleatorio(); //Se mezcla la matriz con todas las cartas
//                dibujar(); //Se vuelve a dibujar todo
//            }

            //Se verifica si la posicion del mouse esta dentro de alguna carta de un jugador
            if(jugadores->getValue().verificarPosicion(ratonx,ratony))
            {
                Carta cartaJugador = jugadores->getValue().retornarCarta(ratonx,ratony); //Carta sobre la que se hizo un click
//                jugadores->returnValue().cambiarColor(ratonx,ratony);
//                dibujar();
                resetMouse(); //Cambia la variable del mouse
                bool ponerFicha = false; //Variable para manejar el caso en el que se haya hecho click en una carta de un jugador
                while(!ponerFicha)
                {

                    delay(10);
                    if (ismouseclick(WM_LBUTTONDOWN))
                    {
                         ratonx = mousex();
                         ratony = mousey();

                         //Verificacion en el caso en que se haga un click en el tablero
                         if (tablero->verificarCoor(ratonx,ratony))
                         {
                            Carta cartaTablero = tablero->getCarta(ratonx,ratony); //Carta del tablero sobre la qe se hizo click
                            if( cartaJugador.getNombre() == cartaTablero.getNombre()) //Se compara si los nombres de las cartas son iguales
                            {
                                jugadores->returnValue().insertar(mazo->pop(),cartaJugador.getPosicion());
                                //Se mete al mazo de cartas usadas la carta que se utilizo y ademas se pone una nueva carta en la mano del jugador
                                mazoDescarte->push(cartaJugador);

                                //Se coloca una ficha sobre la carta del tablero
                                tablero->cambiarColor(ratonx,ratony,jugadores->getValue().getColor(),jugadores->getValue().getNombre());

                                //Pasa al siguiente jugador de la lista
                                jugadores->next();

                                //Se vuelve a dibujar todo
                                dibujar();
                            }
                            else if((strcmp("J2D",cartaJugador.getNombre()) == 0 ||
                                     strcmp("J2T",cartaJugador.getNombre()) == 0 ) &&
                                    !cartaTablero.getFicha())
                            {
                                jugadores->returnValue().insertar(mazo->pop(),cartaJugador.getPosicion());
                                mazoDescarte->push(cartaJugador);
                                tablero->cambiarColor(ratonx,ratony,jugadores->getValue().getColor(),jugadores->getValue().getNombre());
                                jugadores->next();
                                dibujar();
                            }
                            else if((strcmp("J1E",cartaJugador.getNombre()) == 0 ||
                                     strcmp("J1C",cartaJugador.getNombre()) == 0 ) &&
                                    cartaTablero.getFicha())
                            {
                                jugadores->returnValue().insertar(mazo->pop(),cartaJugador.getPosicion());
                                mazoDescarte->push(cartaJugador);
                                tablero->cambiarColor(ratonx,ratony);
                                jugadores->next();
                                dibujar();
                            }

                          }
                         ponerFicha = true; //Se termina el ciclo
                         resetMouse();
                    }

                }

            }
            resetMouse();
        }
    }
}

void Controladora::dibujar()
//Metodo que va a dibuar todos los botones y objetos que se necesitan en pantalla
{
    cleardevice(); //Para que no se sobrepongan las letras
    //rand->dibujar(); //Boton del random
    mazoDescarte->dibujarTop(); //Ultima carta que se boto
    tablero->mostrar(); //Dibuja la matriz con las cartas
    jugadores->getValue().dibujar(); //Dibuja el jugador actual

}

void Controladora::barajar()
//Metodo para entregar las cartas a los jugadores y varia dependiendo de los jugadores
{
    int cartas7 = 7;
    int cartas6 = 6;

    if (cantidadJugadores == 2)
    {

        jugadores = new CArrayList<Jugador>(cantidadJugadores);

        jugadores->append(Jugador(cartas7,8,"Jugador 1"));
        jugadores->append(Jugador(cartas7,14,"Jugador 2"));

        jugadores->goToStart();
        for (int i = 0; i < cantidadJugadores; i++)
        {

            for (int j = 0; j < cartas6; j++)
            {
                jugadores->getValue().append(mazo->pop());
            }
            jugadores->returnValue().asignarPos();
            jugadores->next();
        }
    }
     if (cantidadJugadores == 3)
    {

        jugadores = new CArrayList<Jugador>(cantidadJugadores);

        jugadores->append(Jugador(cartas6,8,"Jugador 1"));
        jugadores->append(Jugador(cartas6,14,"Jugador 2"));
        jugadores->append(Jugador(cartas6,6,"Jugador 3"));

        jugadores->goToStart();
        for (int i = 0; i < cantidadJugadores; i++)
        {

            for (int j = 0; j < cartas6; j++)
            {
                jugadores->getValue().append(mazo->pop());
            }
            jugadores->returnValue().asignarPos();
            jugadores->next();
        }
    }
     if (cantidadJugadores == 4)
    {

        jugadores = new CArrayList<Jugador>(cantidadJugadores);

        jugadores->append(Jugador(cartas6,8,"Equipo 1"));
        jugadores->append(Jugador(cartas6,6,"Equipo 2"));
        jugadores->append(Jugador(cartas6,8,"Equipo 1"));
        jugadores->append(Jugador(cartas6,6,"Equipo 2"));

        jugadores->goToStart();
        for (int i = 0; i < cantidadJugadores; i++)
        {

            for (int j = 0; j < cartas6; j++)
            {
                jugadores->getValue().append(mazo->pop());
            }
            jugadores->returnValue().asignarPos();
            jugadores->next();
        }
    }

}

void Controladora::resetMouse()
//Metodo que resetea el valor de la variable en la se almacena un click
{
    int resetx;
    int resety;
    getmouseclick(WM_LBUTTONDOWN,resetx,resety);
}

Controladora::~Controladora()
{
    //dtor
}
