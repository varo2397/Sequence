#ifndef MATRIZ_H
#define MATRIZ_H
#include "Carta.h"
#include <stdlib.h>
#include <iostream>
class Matriz
{
    public:
        Matriz();
        void setPosition(int posx,int posy);
        void mostrar();
        void aleatorio();
        bool verificarCoor(int posx,int posy);
       // void ponerFicha(int color,char* nombre)
        Carta getValor(int posx,int posy);
        Carta getCarta(int posx,int posy);
        void cambiarColor(int posx,int posy, int color,char* nombreJugador);
        void cambiarColor(int posx,int posy);
        virtual ~Matriz();

    protected:

    private:
        Carta matriz[10][10]; //Matriz de 10x10
};

#endif // MATRIZ_H
