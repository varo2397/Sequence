#ifndef BOTON_H
#define BOTON_H
#include "graphics.h"
#include "Carta.h"

class Boton:public Carta
{
    public:
        Boton(int xArr,int yArr,char* nombre,int color,int separar);\
        void dibujar();

        virtual ~Boton();

    protected:

    private:

};

#endif // BOTON_H
